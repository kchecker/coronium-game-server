local globals = {}

return globals