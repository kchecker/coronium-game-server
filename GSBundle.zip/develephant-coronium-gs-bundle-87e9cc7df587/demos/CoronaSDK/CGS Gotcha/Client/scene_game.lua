--======================================================================--
--== Coronium GS Gotcha 'Game' Scene
--== Author: Chris Byerley
--== Twitter: @develephant
--======================================================================--
local globals = require( 'globals' )
local gs = globals.gs
local p = gs.p

local composer = require( "composer" )
local scene = composer.newScene()

local UI = require( 'ui.UI' ):new()
local sfx = require( 'sfx.Sfx' ):new()
--======================================================================--
--== UI handlers
--======================================================================--
local ui --== ui holder ref

local board_cache = nil
local spots_selected = 0
local spots_select_max = 4

local ui_lock = true

local function setStatus( str )
    ui.status_txt.text = str
end

local function onBtnTapped( e )

    sfx:playSound( "tap" )

    local btn = e.target
    local spot = btn.spot
    local phase = globals.phase

    if phase == 'selecting' then
        spots_selected = spots_selected + 1
        gs:send( { spot = spot } )

        board_cache[ spot ] = 1

        UI:updateBoard( board_cache, onBtnTapped, true )

        --== All selected
        if spots_selected == spots_select_max then
            setStatus( "Waiting for other player..." )
            gs:send( { player_ready = 1 } )
        end
    elseif phase == 'playing' then
        if not ui_lock then
            ui_lock = true
            gs:send( { try_spot = btn.spot } )
        end
    end

end

--======================================================================--
--== Game/Client handlers
--======================================================================--
local function onClientData( event )
    p( event.data )

    ui_lock = false

    local data = event.data

    local player_num = gs:getPlayerNum()
    local can_play = false

    --======================================================================--
    --== Set Phase
    --======================================================================--
    if data.set_phase then
        globals.phase = data.phase
    --======================================================================--
    --== Players ready
    --======================================================================--
    elseif data.players_ready then
        globals.phase = "playing"

        local board = data.board

        if data.starting_player == player_num then

            sfx:playSound( "turn" )

            setStatus( "Your turn. Select a spot..." )
            can_play = true
            UI:updateBoard( board, onBtnTapped, can_play, true )
            --UI:updateBoard( board_cache, onBtnTapped, can_play, true )
        else
            setStatus( "Waiting for other player..." )
            can_play = false
            UI:updateBoard( board, nil, can_play, true )
            --UI:updateBoard( board_cache, nil, can_play, true )
        end
    --======================================================================--
    --== Board update
    --======================================================================--
    elseif data.player_board then
        sfx:playSound( "turn" )
        globals.phase = "selecting"
        board_cache = data.board
        can_play = true
        UI:updateBoard( data.board, onBtnTapped, can_play )
    --======================================================================--
    --== Player hit
    --======================================================================--
    elseif data.did_hit then
        sfx:playSound( "bomb" )
        sfx:playSound( "cheer" )
        setStatus( "You HIT the other player!!" )
        can_play = false
        UI:updateBoard( data.board, nil, can_play )
    elseif data.got_hit then
        sfx:playSound( "bomb" )
        sfx:playSound( "turn" )
        setStatus( "You got HIT!! Your turn." )
        can_play = true
        UI:updateBoard( data.board, onBtnTapped, can_play )
    --======================================================================--
    --== Player miss
    --======================================================================--
    elseif data.missed then
        sfx:playSound( "miss" )
        if data.player_turn == player_num then
            sfx:playSound( "turn" )
            setStatus( "Your turn. Select a spot..." )
            can_play = true
            UI:updateBoard( data.board, onBtnTapped, can_play )
        else
            setStatus( "Waiting for other player..." )
            can_play = false
            UI:updateBoard( data.board, onBtnTapped, can_play )
        end
    --======================================================================--
    --== Game done
    --======================================================================--
    elseif data.game_done then
        globals.phase = 'gameover'

        local winning_player = data.winning_player
        if player_num == winning_player then
            sfx:playSound( "cheer" )
            setStatus( "You WON!!" )
        else
            setStatus( "You lost the game..." )
        end

        ui.ping_txt.text = "Game Over"
        ui.ping_txt.alpha = 1

        --== Disconnect
        gs:_closeGame()
    end

end

local function onClientPing( event )
    local ts = event.data
    local latency = ( os.time() - ts ) * .5

    ui.ping_txt.alpha = 0
    ui.ping_txt.text = "latency: " .. latency .. "ms"

    transition.fadeIn( ui.ping_txt )
end

local function onClientClose( event )
    ui.ping_txt.text = "Game Over"
    ui.ping_txt.alpha = 1
end
--======================================================================--
--== Scene handlers
--======================================================================--
function scene:create( event )
    local sceneGroup = self.view
end

function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then

        ui = UI:drawGame()

        sceneGroup:insert( ui.grp )

        ui.user_txt.text = gs:getPlayerHandle()

    elseif ( phase == "did" ) then

        --== Listen for GameData
        gs.events:on( "GameData", onGameData )

        --== Listen for ClientData
        gs.events:on( "ClientData", onClientData )

        --== Listen for pingu
        gs.events:on( "ClientPing", onClientPing )

        --== Listen for ClientClose
        gs.events:on( "ClientClose", onClientClose )

        --==Ask for board data
        gs:send( { get_board = 1 } )

        print( 'game' )
        
    end
end

function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then

        --== Clear GS listeners
        gs.events:removeEventListener( "GameData", onGameData )
        gs.events:removeEventListener( "ClientData", onClientData )
        gs.events:removeEventListener( "ClientPing", onClientPing )
        gs.events:removeEventListener( "ClientClose", onClientClose )

    elseif ( phase == "did" ) then
        -- Called immediately after scene goes off screen.
    end
end

function scene:destroy( event )
    local sceneGroup = self.view
end

--======================================================================--
--== Listeners
--======================================================================--

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene